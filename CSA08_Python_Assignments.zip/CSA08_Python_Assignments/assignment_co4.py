"""Assignment 4 - CO4: Files, Exceptions, Modules and Logging.
Run: python assignment_co4.py
Sample input files are created in the data/ folder when this program starts.
"""
import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"


def create_sample_files():
    """Create small sample input files so every demonstration can run."""
    DATA_DIR.mkdir(exist_ok=True)
    mess_file = DATA_DIR / "mess_oct.txt"
    if not mess_file.exists():
        mess_file.write_text(
            "192572081,Ruchita,1250.50\n"
            "192573005,Swetha,980\n"
            "192573010,Arun,invalid\n"
            "damaged record\n\n",
            encoding="utf-8"
        )

    attendance_dir = DATA_DIR / "attendance"
    attendance_dir.mkdir(exist_ok=True)
    sample = attendance_dir / "attendance_day1.csv"
    if not sample.exists():
        sample.write_text(
            "192311001,2026-10-08,P\n"
            "192311002,2026-10-08,A\n"
            "192311003,2026-10-08\n"
            "192311004,2026-10-08,L\n",
            encoding="utf-8"
        )


# TASK 1 - Robust hostel mess bill processing
def process_mess_file(filename):
    total = Decimal("0.00")
    report_lines = []
    rejected = []

    with open(filename, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if not line.strip():
                continue
            parts = line.rstrip("\n").split(",")
            if len(parts) != 3:
                rejected.append((line_number, line.rstrip(), "expected 3 fields"))
                continue
            reg_no, name, amount_text = (part.strip() for part in parts)
            try:
                amount = Decimal(amount_text)
                if not amount.is_finite():
                    raise InvalidOperation
            except InvalidOperation:
                rejected.append((line_number, line.rstrip(), "invalid amount"))
                continue
            total += amount
            report_lines.append(f"{reg_no} {name} {amount:.2f}")

    return "\n".join(report_lines), total, rejected


def task1_demo():
    print("\nTASK 1 - Hostel Mess Bill Processing")
    report, total, rejected = process_mess_file(DATA_DIR / "mess_oct.txt")
    print(report)
    print("Total:", f"{total:.2f}")
    print("Rejected records:")
    for item in rejected:
        print(item)


# TASK 2 - Attendance summary, low-attendance report and damaged-line log
def process_attendance_folder(folder, output_folder):
    folder = Path(folder)
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    counts = {}
    errors = []

    for file_path in sorted(folder.glob("*.csv")):
        with file_path.open("r", encoding="utf-8", newline="") as file:
            reader = csv.reader(file)
            for line_number, row in enumerate(reader, start=1):
                if len(row) != 3:
                    errors.append((file_path.name, line_number,
                                   ",".join(row), "expected 3 fields"))
                    continue
                reg_no, date_text, status = (field.strip() for field in row)
                if status not in {"P", "A"} or not reg_no or not date_text:
                    errors.append((file_path.name, line_number,
                                   ",".join(row), "invalid field or status"))
                    continue
                counts.setdefault(reg_no, {"present": 0, "total": 0})
                counts[reg_no]["total"] += 1
                if status == "P":
                    counts[reg_no]["present"] += 1

    summary_path = output_folder / "monthly_summary.csv"
    low_path = output_folder / "low_attendance.csv"
    errors_path = output_folder / "attendance_errors.csv"

    with summary_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["register_number", "present", "total", "percentage"])
        for reg_no, values in sorted(counts.items()):
            percentage = values["present"] / values["total"] * 100
            writer.writerow([reg_no, values["present"], values["total"],
                             f"{percentage:.2f}"])

    with low_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["register_number", "attendance_percentage"])
        for reg_no, values in sorted(counts.items()):
            percentage = values["present"] / values["total"] * 100
            if percentage < 75:
                writer.writerow([reg_no, f"{percentage:.2f}"])

    with errors_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["filename", "line_number", "raw_line", "reason"])
        writer.writerows(errors)

    return counts, errors, (summary_path, low_path, errors_path)


def task2_demo():
    print("\nTASK 2 - Attendance File Processing")
    counts, errors, output_paths = process_attendance_folder(
        DATA_DIR / "attendance", DATA_DIR / "reports"
    )
    print("Student counts:", counts)
    print("Damaged records:", errors)
    print("Reports created:")
    for path in output_paths:
        print("-", path.relative_to(BASE_DIR))


# TASK 3 - Specific exception handling for attendance records
class InvalidRecord(Exception):
    """Raised when an attendance row has invalid fields."""


def parse_attendance_line(line):
    parts = [part.strip() for part in line.strip().split(",")]
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    reg_no, date_text, status = parts
    if not reg_no or not date_text:
        raise InvalidRecord("register number and date are required")
    if status not in {"P", "A"}:
        raise InvalidRecord(f"invalid status {status!r}")
    return reg_no, date_text, status


def summarise_attendance(path):
    present = 0
    absent = 0
    errors = []
    path = Path(path)

    try:
        with path.open("r", encoding="utf-8") as file:
            for line_no, line in enumerate(file, start=1):
                if not line.strip():
                    continue
                try:
                    _, _, status = parse_attendance_line(line)
                except InvalidRecord as exc:
                    errors.append((line_no, str(exc)))
                    continue
                if status == "P":
                    present += 1
                else:
                    absent += 1
    except (FileNotFoundError, PermissionError, UnicodeDecodeError) as exc:
        raise RuntimeError(f"Could not process {path}") from exc
    else:
        print("File processed successfully")
    finally:
        print("Processing attempt finished")

    return present, absent, errors


def task3_demo():
    print("\nTASK 3 - Exception Handling")
    result = summarise_attendance(DATA_DIR / "attendance" / "attendance_day1.csv")
    print("Attendance result:", result)
    try:
        summarise_attendance(DATA_DIR / "attendance" / "missing.csv")
    except RuntimeError as exc:
        print("Handled file error:", exc)
        print("Original cause:", type(exc.__cause__).__name__)


# TASK 4 - Append daily returned-book records and persist errors
def log_returns(log_path, returned_books):
    path = Path(log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as file:
        for book_id, title in returned_books:
            file.write(
                f"{datetime.now().isoformat(timespec='seconds')} | "
                f"{book_id} | {title}\n"
            )


def log_error(error_path, exc):
    path = Path(error_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as file:
        file.write(
            f"{datetime.now().isoformat(timespec='seconds')} | "
            f"{type(exc).__name__}: {exc}\n"
        )


def task4_demo():
    print("\nTASK 4 - Library Return and Error Logging")
    log_path = DATA_DIR / "returns.log"
    error_path = DATA_DIR / "errors.log"

    # Simulate three days. Append mode preserves previous records.
    daily_returns = [
        [("B101", "Python Basics")],
        [("B102", "Learning Algorithms")],
        [("B103", "Data Structures")]
    ]
    for books in daily_returns:
        log_returns(log_path, books)

    try:
        # Deliberately demonstrate a handled file error.
        with (DATA_DIR / "missing_library_file.txt").open(
                "r", encoding="utf-8"):
            pass
    except OSError as exc:
        log_error(error_path, exc)
        print("An error occurred and was saved to errors.log")

    print("Return log:", log_path.relative_to(BASE_DIR))
    print("Error log:", error_path.relative_to(BASE_DIR))
    print("Return records currently stored:")
    print(log_path.read_text(encoding="utf-8"))


def main():
    create_sample_files()
    actions = {
        "1": task1_demo,
        "2": task2_demo,
        "3": task3_demo,
        "4": task4_demo
    }
    while True:
        print("\n===== ASSIGNMENT 4 - CO4 =====")
        print("1. Hostel mess bill file processing")
        print("2. Attendance summary and error reports")
        print("3. Exception handling and validation")
        print("4. Library return and error logging")
        print("0. Exit")
        choice = input("Choose a task: ").strip()
        if choice == "0":
            break
        if choice in actions:
            actions[choice]()
        else:
            print("Invalid choice. Select 0 to 4.")


if __name__ == "__main__":
    main()
