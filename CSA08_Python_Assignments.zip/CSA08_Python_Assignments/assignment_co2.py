"""Assignment 2 - CO2: Control Flow, Strings and Functions.
Run: python assignment_co2.py
No third-party packages are required.
"""
import io
import time
from functools import lru_cache
import sys


# Q1 - Electricity subsidy eligibility
def subsidy(units, ration_card, senior_over_80):
    if units <= 100:
        return "Full subsidy"
    elif 101 <= units <= 200:
        return "Partial subsidy" if ration_card else "No subsidy"
    elif units > 200 and senior_over_80:
        return "Senior-citizen exception"
    return "No subsidy"


def q1_demo():
    print("\nQ1 - Electricity Subsidy")
    cases = [
        (100, False, False), (101, True, False), (200, True, False),
        (201, False, False), (201, False, True), (150, False, True),
        (80, True, True), (200, False, True)
    ]
    for case in cases:
        print(case, "->", subsidy(*case))


# Q2 - OTP verification: blank entries do not consume attempts
def verify_otp(correct_otp, max_attempts=3):
    attempts = 0
    while attempts < max_attempts:
        entered = input("Enter OTP: ").strip()
        if not entered:
            print("Blank entry: try again (not counted)")
            continue
        attempts += 1
        if entered == str(correct_otp):
            print("Verified")
            return True
        print("Incorrect")
    print("Account locked for 30 minutes")
    return False


# Q3 - Vehicle registration number validator
def normalise_registration(text):
    return text.strip().upper().replace(" ", "").replace("-", "")


def is_valid_registration(reg):
    if len(reg) not in (9, 10):
        return False
    return (
        reg[:2].isalpha()
        and reg[2:4].isdigit()
        and reg[4:-4].isalpha()
        and len(reg[4:-4]) in (1, 2)
        and reg[-4:].isdigit()
    )


def format_registration(reg):
    if not is_valid_registration(reg):
        raise ValueError("Invalid registration number")
    return f"{reg[:2]} {reg[2:4]} {reg[4:-4]} {reg[-4:]}"


def q3_demo():
    print("\nQ3 - Vehicle Registration Validation")
    samples = ["tn 09 ab 1234", "KA-01-M-0007", "TN9AB1234",
               "TN 22 1234 AB", "MH 12 Q 7788", "XX-99-ZZ-0001"]
    for raw in samples:
        reg = normalise_registration(raw)
        status = "Valid" if is_valid_registration(reg) else "INVALID"
        print(f"{raw} -> {reg}: {status}")
        if is_valid_registration(reg):
            print("Receipt:", format_registration(reg))


# Q4 - Building long text using +, join() and StringIO
def build_plus(parts):
    result = ""
    for part in parts:
        result += part + ";"
    return result


def build_join(parts):
    return ";".join(parts) + (";" if parts else "")


def build_stringio(parts):
    output = io.StringIO()
    for part in parts:
        output.write(part)
        output.write(";")
    return output.getvalue()


def q4_demo():
    print("\nQ4 - String Building Comparison")
    for size in (1_000, 10_000, 200_000):
        items = [f"Item{i}:Rs{i % 50}" for i in range(size)]
        results = {}
        outputs = {}
        for fn in (build_plus, build_join, build_stringio):
            start = time.perf_counter()
            outputs[fn.__name__] = fn(items)
            results[fn.__name__] = time.perf_counter() - start
        same = len(set(outputs.values())) == 1
        print(f"{size:,} items | " +
              " | ".join(f"{name}: {elapsed:.6f}s"
                         for name, elapsed in results.items()))
        print("All outputs identical:", same)


# Q5 - Functions, parameters, mutable defaults and scope
def add_item_buggy(item, order=[]):
    order.append(item)
    return order


def add_item(item, order=None):
    if order is None:
        order = []
    order.append(item)
    return order


def bill(subtotal, gst_rate=0.05):
    gst = subtotal * gst_rate
    return subtotal + gst, gst


def make_counter():
    count = 0

    def next_value():
        nonlocal count
        count += 1
        return count

    return next_value


def q5_demo():
    print("\nQ5 - Functions and Scope")
    print("Buggy shared default:", add_item_buggy("Tea"), add_item_buggy("Vada"))
    print("Correct separate lists:", add_item("Tea"), add_item("Vada"))
    total, gst = bill(200, gst_rate=0.05)
    print(f"Bill total: {total:.2f}; GST: {gst:.2f}")
    counter = make_counter()
    print("Closure counter:", counter(), counter())
    customers = {}
    for name, item in [("Asha", "Tea"), ("Bala", "Coffee"),
                       ("Chitra", "Juice")]:
        customers[name] = add_item(item)
    print("Customer orders:", customers)


# Q6 - Climbing stairs using recursion, memoisation and iteration
calls = 0


def ways_naive(n):
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)


@lru_cache(maxsize=None)
def ways_memo(n):
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)


def ways_loop(n):
    if n < 0:
        raise ValueError("Number of steps cannot be negative")
    if n <= 1:
        return 1
    a, b = 1, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


def q6_demo():
    global calls
    print("\nQ6 - Climbing Stairs")
    for n in range(1, 7):
        print(f"{n} steps -> {ways_loop(n)} ways")
    calls = 0
    print("Naive recursion for 25:", ways_naive(25), "| calls:", calls)
    ways_memo.cache_clear()
    print("Memoised recursion for 25:", ways_memo(25))
    print("Iterative method for 1000 steps: result has",
          len(str(ways_loop(1000))), "digits")
    print("Python recursion limit:", sys.getrecursionlimit())


# Q7 - Diagnose and optimise statement builder
def q7_demo():
    print("\nQ7 - Optimised SMS Statement Builder")
    for size in (1_000, 10_000, 200_000):
        data = [f"Call{i}" for i in range(size)]
        timings = {}
        outputs = {}
        for name, fn in (("plus", build_plus), ("join", build_join)):
            start = time.perf_counter()
            outputs[name] = fn(data)
            timings[name] = time.perf_counter() - start
        print(f"{size:,} records | plus={timings['plus']:.6f}s "
              f"| join={timings['join']:.6f}s "
              f"| identical={outputs['plus'] == outputs['join']}")


def main():
    demos = {
        "1": q1_demo, "3": q3_demo, "4": q4_demo,
        "5": q5_demo, "6": q6_demo, "7": q7_demo
    }
    while True:
        print("\n===== ASSIGNMENT 2 - CO2 =====")
        print("1. Electricity subsidy")
        print("2. OTP verification (interactive)")
        print("3. Vehicle registration validation")
        print("4. String building comparison")
        print("5. Functions and scope")
        print("6. Recursion and climbing stairs")
        print("7. Diagnose and optimise string builder")
        print("0. Exit")
        choice = input("Choose a question: ").strip()
        if choice == "0":
            break
        if choice == "2":
            verify_otp(input("Set the correct OTP for this demo: ").strip())
        elif choice in demos:
            demos[choice]()
        else:
            print("Invalid choice. Select 0 to 7.")


if __name__ == "__main__":
    main()
