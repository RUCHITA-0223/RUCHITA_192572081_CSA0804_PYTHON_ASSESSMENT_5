"""Assignment 3 - CO3: Python Data Structures.
Run: python assignment_co3.py
"""
import copy
import string
from collections import Counter, defaultdict


# Q1 - Daily rainfall records and moving averages
def moving_average_naive(values, window=7):
    if window <= 0:
        raise ValueError("Window must be positive")
    if len(values) < window:
        return []
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]


def moving_average_running(values, window=7):
    if window <= 0:
        raise ValueError("Window must be positive")
    if len(values) < window:
        return []
    current = sum(values[:window])
    result = [current / window]
    for i in range(window, len(values)):
        current += values[i] - values[i - window]
        result.append(current / window)
    return result


def q1_demo():
    print("\nQ1 - Daily Rainfall")
    rain = [0, 2, 5, 1, 0, 7, 3, 4, 6, 0, 2, 8, 1, 0]
    weekly = [sum(rain[i:i + 7]) for i in range(0, len(rain), 7)]
    dry_days = [i + 1 for i, value in enumerate(rain) if value == 0]
    print("Weekly totals:", weekly)
    print("Wettest day (day, rainfall):", max(enumerate(rain, 1), key=lambda x: x[1]))
    print("Driest day (day, rainfall):", min(enumerate(rain, 1), key=lambda x: x[1]))
    print("7-day moving average:", moving_average_running(rain))
    print("Dry days:", dry_days)
    print("Naive and running results match:",
          moving_average_naive(rain) == moving_average_running(rain))


# Q2 - Tuples, mutability and copying
def q2_demo():
    print("\nQ2 - Tuples, Mutability and Copying")
    rows, cols = 3, 4
    bad = [[0] * cols] * rows
    bad[0][1] = 7
    good = [[0 for _ in range(cols)] for _ in range(rows)]
    good[0][1] = 7
    print("Shared-row grid:", bad)
    print("Independent-row grid:", good)
    print("Rows share identity?", bad[0] is bad[1], good[0] is good[1])

    stops = {(13.0827, 80.2707): "Chennai Central",
             (13.0418, 80.2341): "T. Nagar"}
    print("Tuple-key lookup:", stops[(13.0418, 80.2341)])

    original = [[1, 2], [3, 4]]
    alias = original
    shallow = copy.copy(original)
    deep = copy.deepcopy(original)
    original[0][0] = 99
    original[1].append(5)
    print("Alias:", alias)
    print("Shallow copy:", shallow)
    print("Deep copy:", deep)


# Q3 - Word frequencies and complaint grouping
def frequencies(texts, stop_words):
    counts = {}
    for text in texts:
        words = text.lower().translate(
            str.maketrans("", "", string.punctuation)
        ).split()
        for word in words:
            if word not in stop_words:
                counts[word] = counts.get(word, 0) + 1
    return counts


def top_words(counts, k):
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:k]


def q3_demo():
    print("\nQ3 - Farmer Helpline Complaint Analysis")
    calls = ["seeds not received seeds delayed",
             "fertiliser price high",
             "seeds price high subsidy not received"]
    stop_words = {"not", "high"}
    counts = frequencies(calls, stop_words)
    print("Top 3 words:", top_words(counts, 3))

    complaints = [
        {"district": "Madurai", "crop": "Rice", "text": "Seeds delayed"},
        {"district": "Dindigul", "crop": "Cotton", "text": "Price high"},
        {"district": "Madurai", "crop": "Rice", "text": "Water shortage"},
    ]
    by_district = defaultdict(list)
    by_crop = defaultdict(list)
    for item in complaints:
        by_district[item["district"]].append(item["text"])
        by_crop[item["crop"]].append(item["text"])
    print("By district:", dict(by_district))
    print("By crop:", dict(by_crop))
    print("Counter:", Counter(" ".join(calls).split()))


# Q4 - Elective registration clash detection
def q4_demo():
    print("\nQ4 - Elective Registration Clash Detection")
    ai_elective = {"192311001", "192311004", "192311007", "192311009"}
    iot_elective = {"192311002", "192311004", "192311009", "192311010"}
    all_students = {f"1923110{i:02d}" for i in range(1, 11)}
    both = ai_elective & iot_elective
    exactly_one = ai_elective ^ iot_elective
    neither = all_students - (ai_elective | iot_elective)
    print("Clash:", sorted(both))
    print("Exactly one:", sorted(exactly_one))
    print("Neither:", sorted(neither))
    assert both == ai_elective.intersection(iot_elective)
    assert exactly_one == ai_elective.symmetric_difference(iot_elective)


# Q5 - Cleaning sensor readings
def q5_demo():
    print("\nQ5 - Cleaning Sensor Readings")
    readings = [4.0, 7.5, 55.0, -60.0, 9.0, 3.5]
    valid_loop = []
    for value in readings:
        if -50 <= value <= 50:
            valid_loop.append(value)
    valid_comp = [value for value in readings if -50 <= value <= 50]
    fahrenheit = [value * 9 / 5 + 32 for value in valid_comp]
    valid_map = list(filter(lambda value: -50 <= value <= 50, readings))
    fahrenheit_map = list(map(lambda value: value * 9 / 5 + 32, valid_map))
    alarms = [(minute, value) for minute, value in enumerate(readings)
              if -50 <= value <= 50 and not (2 <= value <= 8)]
    celsius_by_minute = {i: value for i, value in enumerate(valid_comp)}
    unique_valid = {value for value in readings if -50 <= value <= 50}
    print("Loop:", valid_loop)
    print("Comprehension:", valid_comp)
    print("Filter/map:", valid_map)
    print("Fahrenheit:", fahrenheit)
    print("Fahrenheit using map:", fahrenheit_map)
    print("Alarm readings (minute, Celsius):", alarms)
    print("Dictionary:", celsius_by_minute)
    print("Unique readings:", unique_valid)


# Q6 - Railway timetable using nested data structures
def q6_demo():
    print("\nQ6 - Railway Timetable")
    trains = {
        "12631": {"name": "Nellai Express",
                  "stops": [("Chennai", "20:10", "20:20"),
                            ("Villupuram", "22:30", "22:32"),
                            ("Madurai", "04:50", "05:00")],
                  "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}},
        "12633": {"name": "Kanyakumari Express",
                  "stops": [("Chennai", "19:45", "20:00"),
                            ("Villupuram", "22:00", "22:02"),
                            ("Madurai", "04:20", "04:25")],
                  "days": {"Mon", "Wed", "Fri"}},
        "12635": {"name": "Vaigai Express",
                  "stops": [("Chennai", "13:50", "14:00"),
                            ("Villupuram", "16:00", "16:02"),
                            ("Madurai", "21:00", "21:05")],
                  "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}},
        "16127": {"name": "Guruvayur Express",
                  "stops": [("Chennai", "10:00", "10:10"),
                            ("Villupuram", "12:30", "12:32"),
                            ("Madurai", "18:30", "18:35")],
                  "days": {"Tue", "Thu", "Sat"}},
        "20605": {"name": "Chennai Express",
                  "stops": [("Chennai", "06:00", "06:10"),
                            ("Villupuram", "08:30", "08:32"),
                            ("Madurai", "14:00", "14:05")],
                  "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}}
    }
    station, day = "Madurai", "Mon"
    matches = []
    for number, info in trains.items():
        if day in info["days"]:
            for stop, arrival, departure in info["stops"]:
                if stop == station:
                    matches.append((departure, number, info["name"]))
                    break
    print(f"Departures from {station} on {day}:")
    for item in sorted(matches):
        print(item)
    print("12631 third-stop departure:", trains["12631"]["stops"][2][2])


# Q7 - Merge contacts using normalised phone numbers
def normalise_phone(phone):
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    return digits


def merge_contacts(contact_lists):
    merged = {}
    for contacts in contact_lists:
        for contact in contacts:
            phone = contact.get("phone", "")
            key = normalise_phone(phone)
            if not key:
                continue
            record = merged.setdefault(key, {
                "names": set(), "phones": set(), "emails": set()
            })
            if contact.get("name"):
                record["names"].add(contact["name"].strip())
            if phone:
                record["phones"].add(phone.strip())
            if contact.get("email"):
                record["emails"].add(contact["email"].strip().lower())
    return merged


def q7_demo():
    print("\nQ7 - Contact Merging")
    phones_a = [
        {"name": "Dr. Ravi", "phone": "+91 98400 12345",
         "email": "RAVI@MAIL.COM"},
        {"name": "Meena", "phone": "9876543210",
         "email": "meena@mail.com"}
    ]
    phones_b = [
        {"name": "Ravi Kumar", "phone": "9840012345",
         "email": "ravi2@mail.com"},
        {"name": "Meena", "phone": "98765-43210",
         "email": "meena@mail.com"}
    ]
    result = merge_contacts([phones_a, phones_b])
    for number, data in sorted(result.items()):
        print(number, {
            key: sorted(value) for key, value in data.items()
        })


def main():
    demos = {"1": q1_demo, "2": q2_demo, "3": q3_demo,
             "4": q4_demo, "5": q5_demo, "6": q6_demo,
             "7": q7_demo}
    while True:
        print("\n===== ASSIGNMENT 3 - CO3 =====")
        for number, title in [
            ("1", "Rainfall and moving averages"),
            ("2", "Tuples, mutability and copying"),
            ("3", "Dictionary word and complaint analysis"),
            ("4", "Set-based elective clash detection"),
            ("5", "Sensor reading cleaning"),
            ("6", "Railway timetable"),
            ("7", "Contact merging")
        ]:
            print(f"{number}. {title}")
        print("0. Exit")
        choice = input("Choose a question: ").strip()
        if choice == "0":
            break
        if choice in demos:
            demos[choice]()
        else:
            print("Invalid choice. Select 0 to 7.")


if __name__ == "__main__":
    main()
